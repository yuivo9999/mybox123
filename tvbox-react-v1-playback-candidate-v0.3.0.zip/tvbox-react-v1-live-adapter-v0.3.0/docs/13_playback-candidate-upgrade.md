# Stage 13：Playback Candidate 与播放链路第一次升级记录

基线：`tvbox-react-v1-live-adapter-v0.3.0`

依据：`tvbox竖屏后续/13_播放候选与播放链路改造实施方案.md`

## 本次施工范围

```text
Movie Episode / Live Channel
        ↓
PlaybackCandidate[]
        ↓
PlaybackRequest
        ↓
PlaybackTask / PlaybackCore
        ↓
后续 Parser / Player Adapter（14/15）
```

### 新增模块

- `src/models/playback.js`
  - PlaybackCandidate
  - PlaybackRequest
  - requestId / taskId
  - VOD / Live kind
  - fallbackCandidateIds
  - 运行时错误分类
- `src/services/playbackService.js`
  - VOD candidate 生成
  - Live stream → candidate 转换
  - PlaybackRequest 创建
  - PlaybackTask 创建
  - 短重试 / 下一候选 / 手动切源 / 失败记录 / release
- `src/playback/playbackCore.js`
  - 为 14 Parser 与 15 Player Adapter 保留稳定编排边界
  - 本阶段不实现 Parser / Player SDK

### 既有模型调整

- Episode 增加 `playbackCandidates`。
- Live 继续保持 `Channel → Stream` 业务模型；播放入口时统一转换为 `PlaybackCandidate`。
- 旧 Live `url` 继续兼容，但统一播放输入使用 `mediaUrl`。
- 用户收藏、历史、进度 ID 体系不改变。

### 页面调整

- VOD 与 Live 播放入口均先创建 `PlaybackRequest`。
- 播放页面不再自行决定播放 URL，而消费 `PlaybackCore` 当前候选。
- 播放组件卸载时执行 stop/release，避免旧任务继续持有运行时资源。
- 候选失败后进入下一候选；已经失败的候选不能被 fallback 再次自动选择。

## 验证

- `npm run test:live`：通过
- `npm run test:playback`：通过
- `npm run test`：通过
- 新增核心 JS 模块 `node --check`：通过
- `src/main.jsx` JSX 语法转换检查：通过
- `npm run build`：本交付容器未安装 `node_modules`，因此未宣称构建通过；项目仍保留标准 Vite build 脚本。
