# TVBox React v0.3.0

这是在 `tvbox-react-v1-data-boundary-v0.2.0` 基础上，依据 `tvbox竖屏后续/11_影视源适配层改造实施方案.md` 完成的第二次施工升级。

## 本次升级：影视源适配层

### 已完成
- 建立 `MovieSourceAdapter` 统一影视源最小契约：能力声明、搜索、分类、列表、详情、剧集、播放候选、健康检查。
- 建立 `SourceRegistry`，以稳定 `sourceId` 注册和查找影视 Adapter。
- 建立明确的 `UnsupportedCapabilityError`，能力缺失不再要求页面猜测。
- 将现有 Demo 影视源采用“包裹而非立即重写”的方式接入 Adapter。
- `ContentService` 通过 Registry 调用 Adapter，不再要求页面理解原始源实现。
- Source 请求采用单源错误隔离：一个源失败不会让其他启用源结果整体失败。
- Adapter 负责把源数据整理为标准 Movie / Detail / Episode / PlaybackCandidate 形态。
- Demo 播放阶段已能够从 Adapter 产生标准 `PlaybackCandidate`，但播放器内核仍属于后续施工阶段。
- 保留 v0.2.0 已建立的用户数据、源配置和迁移边界，不改变收藏/历史/进度的数据命名空间。

### 当前仍属于后续施工阶段
- 真实第三方影视源的网络 Request/Parser 拆分。
- 多源同内容的跨源 `contentId` 合并算法。
- 真正的 Playback Service / Playback Core / Parser / Player Adapter。
- Live Adapter 与 LiveService 改造。
- 页面进一步从静态 Demo 数据切换到异步 SourceService 数据流。

## 目录

```text
src/
├── adapters/         # Movie Source Adapter 与 Source Registry
├── data/             # 当前演示源 fixture
├── models/           # 标准 Content / Episode / Live / UserData 模型
├── repositories/     # Storage 访问边界
├── services/         # 业务编排；ContentService 只通过 Adapter 取源数据
├── storage/          # 本地持久化与旧数据迁移
├── styles/           # 全局样式
└── main.jsx          # 页面组合；不直接请求或解析外部影视源
```

## 目标调用链

```text
Movie Feature / Page
        ↓
Movie Service
        ↓
Source Registry
        ↓
Movie Source Adapter
        ↓
Request / Raw Parser（后续逐步拆入 Adapter）
        ↓
Normalizer
        ↓
Movie / Detail / Episode / PlaybackCandidate
```

当前 Demo 源处于过渡阶段：已有标准数据被 Adapter 包装，避免为了建立边界而重复重写已有演示逻辑。

## 源接入规则

新增影视源原则上只需要：

```text
Source Config
↓
实现 MovieSourceAdapter
↓
声明 capabilities
↓
注册 SourceRegistry
↓
由 ContentService 调用
```

页面不应新增针对某个 sourceId 的特殊判断。

## 验证

```bash
npm install
npm run build
```

本次交付同时进行了源码结构检查；如果执行环境无法完成依赖安装，不把未完成安装伪装为“构建通过”。
