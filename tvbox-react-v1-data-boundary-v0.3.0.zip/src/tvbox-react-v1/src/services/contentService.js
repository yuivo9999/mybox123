import { sourceRegistry } from '../adapters/sourceRegistry';

export class SourceRequestError extends Error {
  constructor(sourceId, operation, cause) {
    super(`Movie source "${sourceId}" failed during ${operation}`);
    this.name = 'SourceRequestError';
    this.code = 'SOURCE_REQUEST_FAILED';
    this.sourceId = sourceId;
    this.operation = operation;
    this.cause = cause;
  }
}

async function safeCall(adapter, operation, callback) {
  try {
    return { sourceId: adapter.sourceId, value: await callback(), error: null };
  } catch (error) {
    return { sourceId: adapter.sourceId, value: null, error: new SourceRequestError(adapter.sourceId, operation, error) };
  }
}

export const contentService = {
  getMovies(items) {
    return items;
  },

  getById(items, contentId) {
    return items.find((item) => item.contentId === contentId) ?? null;
  },

  async search(params = {}, sourceConfigs = []) {
    const adapters = sourceRegistry.getEnabledMovieAdapters(sourceConfigs);
    const results = await Promise.all(adapters.map((adapter) => safeCall(adapter, 'search', () => adapter.search(params))));
    return {
      items: results.flatMap((result) => result.value ?? []),
      sourceErrors: results.filter((result) => result.error).map((result) => result.error),
    };
  },

  async getList(params = {}, sourceConfigs = []) {
    const adapters = sourceRegistry.getEnabledMovieAdapters(sourceConfigs);
    const results = await Promise.all(adapters.map((adapter) => safeCall(adapter, 'getList', () => adapter.getList(params))));
    return {
      items: results.flatMap((result) => result.value ?? []),
      sourceErrors: results.filter((result) => result.error).map((result) => result.error),
    };
  },

  async getDetail(contentRef) {
    const adapter = sourceRegistry.getMovie(contentRef?.sourceId);
    if (!adapter) return { item: null, error: new SourceRequestError(contentRef?.sourceId ?? 'unknown', 'getDetail', new Error('Source not registered')) };
    const result = await safeCall(adapter, 'getDetail', () => adapter.getDetail(contentRef));
    return { item: result.value, error: result.error };
  },

  async getEpisodes(episodeRef) {
    const adapter = sourceRegistry.getMovie(episodeRef?.sourceId);
    if (!adapter) return { items: [], error: new SourceRequestError(episodeRef?.sourceId ?? 'unknown', 'getEpisodes', new Error('Source not registered')) };
    const result = await safeCall(adapter, 'getEpisodes', () => adapter.getEpisodes(episodeRef));
    return { items: result.value ?? [], error: result.error };
  },

  async getPlaybackCandidates(episodeRef) {
    const adapter = sourceRegistry.getMovie(episodeRef?.sourceId);
    if (!adapter) return { candidates: [], error: new SourceRequestError(episodeRef?.sourceId ?? 'unknown', 'getPlaybackCandidates', new Error('Source not registered')) };
    const result = await safeCall(adapter, 'getPlaybackCandidates', () => adapter.getPlaybackCandidates(episodeRef));
    return { candidates: result.value ?? [], error: result.error };
  },

  async healthCheck(sourceConfigs = []) {
    const adapters = sourceRegistry.getEnabledMovieAdapters(sourceConfigs);
    const results = await Promise.all(adapters.map((adapter) => safeCall(adapter, 'healthCheck', () => adapter.healthCheck())));
    return results.map((result) => ({ sourceId: result.sourceId, status: result.value, error: result.error }));
  },
};
