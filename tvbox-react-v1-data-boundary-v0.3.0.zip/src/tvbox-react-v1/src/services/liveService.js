export const liveService = {
  getChannels: (items) => items,
  getById: (items, channelId) => items.find((item) => item.channelId === channelId) ?? null,
};
