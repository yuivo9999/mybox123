import { normalizeContent } from '../models/content';

export const MovieSourceCapability = Object.freeze({
  SEARCH: 'search',
  CATEGORIES: 'categories',
  LIST: 'list',
  DETAIL: 'detail',
  EPISODES: 'episodes',
  PLAYBACK_CANDIDATES: 'playbackCandidates',
  HEALTH_CHECK: 'healthCheck',
});

export class UnsupportedCapabilityError extends Error {
  constructor(sourceId, capability) {
    super(`Source "${sourceId}" does not support capability "${capability}"`);
    this.name = 'UnsupportedCapabilityError';
    this.code = 'UNSUPPORTED_CAPABILITY';
    this.sourceId = sourceId;
    this.capability = capability;
  }
}

export class MovieSourceAdapter {
  constructor(config, implementation) {
    this.config = config;
    this.implementation = implementation;
  }

  get sourceId() {
    return this.config.sourceId;
  }

  getCapabilities() {
    return this.implementation.capabilities ?? [];
  }

  supports(capability) {
    return this.getCapabilities().includes(capability);
  }

  async #invoke(capability, args = {}) {
    if (!this.supports(capability) || typeof this.implementation[capability] !== 'function') {
      throw new UnsupportedCapabilityError(this.sourceId, capability);
    }
    return this.implementation[capability](args);
  }

  async search(params = {}) {
    return this.#invoke(MovieSourceCapability.SEARCH, params);
  }

  async getCategories() {
    return this.#invoke(MovieSourceCapability.CATEGORIES);
  }

  async getList(params = {}) {
    return this.#invoke(MovieSourceCapability.LIST, params);
  }

  async getDetail(contentRef) {
    return this.#invoke(MovieSourceCapability.DETAIL, { contentRef });
  }

  async getEpisodes(contentRef) {
    return this.#invoke(MovieSourceCapability.EPISODES, { contentRef });
  }

  async getPlaybackCandidates(episodeRef) {
    return this.#invoke(MovieSourceCapability.PLAYBACK_CANDIDATES, { episodeRef });
  }

  async healthCheck() {
    return this.#invoke(MovieSourceCapability.HEALTH_CHECK);
  }
}

/**
 * Transitional adapter: wraps the existing normalized demo source instead of
 * rewriting its data parser in this migration step.
 */
export function createDemoMovieAdapter(config, items) {
  const normalizedItems = items.map((item) => normalizeContent({
    sourceId: config.sourceId,
    sourceItemId: item.sourceRefs?.[0]?.sourceItemId ?? item.contentId,
    title: item.title,
    type: item.contentType,
    poster: item.poster,
    backdrop: item.backdrop,
    description: item.description,
    year: item.year,
    category: item.category,
    episodes: item.episodes?.map((episode) => ({
      sourceItemId: episode.sourceRefs?.[0]?.sourceItemId ?? episode.episodeId,
      title: episode.title,
      description: episode.description,
    })) ?? [],
  }));

  const byId = (contentRef) => {
    const sourceItemId = contentRef?.sourceItemId ?? contentRef?.contentId;
    return normalizedItems.find((item) => item.sourceRefs.some((ref) => ref.sourceItemId === sourceItemId)) ?? null;
  };

  return new MovieSourceAdapter(config, {
    capabilities: [
      MovieSourceCapability.SEARCH,
      MovieSourceCapability.CATEGORIES,
      MovieSourceCapability.LIST,
      MovieSourceCapability.DETAIL,
      MovieSourceCapability.EPISODES,
      MovieSourceCapability.PLAYBACK_CANDIDATES,
      MovieSourceCapability.HEALTH_CHECK,
    ],
    async search({ keyword = '' } = {}) {
      const query = keyword.trim().toLowerCase();
      return query ? normalizedItems.filter((item) => item.title.toLowerCase().includes(query)) : normalizedItems;
    },
    async getCategories() {
      return [...new Set(normalizedItems.map((item) => item.category).filter(Boolean))];
    },
    async getList({ category } = {}) {
      return category ? normalizedItems.filter((item) => item.category === category) : normalizedItems;
    },
    async getDetail({ contentRef } = {}) {
      return byId(contentRef);
    },
    async getEpisodes({ contentRef } = {}) {
      return byId(contentRef)?.episodes ?? [];
    },
    async getPlaybackCandidates({ episodeRef } = {}) {
      const content = byId(episodeRef);
      const episode = content?.episodes.find((item) => item.episodeId === episodeRef?.episodeId) ?? content?.episodes[0];
      if (!content || !episode) return [];
      return [{
        candidateId: `candidate:${config.sourceId}:${episode.episodeId}`,
        sourceId: config.sourceId,
        contentId: content.contentId,
        episodeId: episode.episodeId,
        mediaUrl: 'https://storage.googleapis.com/coverr-main/mp4/Mt_Baker.mp4',
        protocol: 'mp4',
        priority: 1,
        metadata: { demo: true },
      }];
    },
    async healthCheck() {
      return { sourceId: config.sourceId, healthy: config.enabled !== false, status: config.status ?? 'unknown' };
    },
  });
}
