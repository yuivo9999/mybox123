import { MovieSourceCapability } from './movieSourceAdapter';

export class SourceRegistry {
  constructor() {
    this.movieAdapters = new Map();
  }

  registerMovie(adapter) {
    if (!adapter?.sourceId) throw new Error('Movie adapter requires a stable sourceId');
    if (this.movieAdapters.has(adapter.sourceId)) throw new Error(`Movie source already registered: ${adapter.sourceId}`);
    this.movieAdapters.set(adapter.sourceId, adapter);
    return adapter;
  }

  getMovie(sourceId) {
    return this.movieAdapters.get(sourceId) ?? null;
  }

  getMovieAdapters() {
    return [...this.movieAdapters.values()];
  }

  getMovieCapabilities(sourceId) {
    return this.getMovie(sourceId)?.getCapabilities() ?? [];
  }

  supportsMovie(sourceId, capability) {
    return this.getMovie(sourceId)?.supports(capability) ?? false;
  }

  getEnabledMovieAdapters(sourceConfigs) {
    const enabledIds = new Set(sourceConfigs.filter((source) => source.enabled !== false && source.sourceType === 'movie').map((source) => source.sourceId));
    return this.getMovieAdapters().filter((adapter) => enabledIds.has(adapter.sourceId));
  }
}

export const sourceRegistry = new SourceRegistry();

export function registerDemoMovieSource(adapter) {
  if (!sourceRegistry.getMovie(adapter.sourceId)) sourceRegistry.registerMovie(adapter);
  return adapter;
}

export { MovieSourceCapability };
