export function createChannelId(sourceId, sourceItemId) {
  return `channel:${sourceId}:${sourceItemId}`;
}

export function createStreamId(sourceId, sourceItemId) {
  return `stream:${sourceId}:${sourceItemId}`;
}

export function normalizeChannel({ sourceId, sourceItemId, name, category, logo = '', streams = [] }) {
  const channelId = createChannelId(sourceId, sourceItemId);
  return {
    channelId,
    name,
    logo,
    category,
    sourceRefs: [{ sourceId, sourceItemId }],
    streams: streams.map((stream, index) => ({
      streamId: createStreamId(sourceId, `${sourceItemId}:${index + 1}`),
      sourceId,
      sourceItemId: stream.sourceItemId ?? `${sourceItemId}:stream:${index + 1}`,
      url: stream.url,
      label: stream.label ?? `线路 ${index + 1}`,
    })),
    epg: [],
    status: 'available',
    syncAt: Date.now(),
  };
}
